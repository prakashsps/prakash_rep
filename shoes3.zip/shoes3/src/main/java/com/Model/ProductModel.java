package com.Model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;



@Entity
public class ProductModel {
    @Id
    @Column
    @NotEmpty(message="Type your Code")
    private String code;
    @Column
    @NotEmpty(message="Type your Name")
    private String name;
    @Column
    @NotEmpty(message="Type your Price")
    private String price;
    @Transient
    private MultipartFile file;
    
    
    public String getcode() {
        return code;
    }

    public void setcode(String code) {
        this.code = code;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
    
}
    