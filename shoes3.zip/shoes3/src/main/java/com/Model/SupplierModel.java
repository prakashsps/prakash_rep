package com.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class SupplierModel {
	@Id
	@Column
    private String code;
    @Column
    private String name;
    @Column
    private String category;
    
    public String getcode () {
        return code;
    }

    public void setcode (String code) {
        this.code = code;
    }  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    public String getCategory() {
        return category;
    }

}
       
