package DAO;

import java.util.List;

import Model.ProductModel;

public interface ProductDAO { 
	void addProduct(ProductModel p);
    void viewProduct(String code );
    void deleteProduct(ProductModel p);
    void editProduct(ProductModel p);
    List<ProductModel>ViewProductModel();
    ProductModel viewProductby(String code);
}
