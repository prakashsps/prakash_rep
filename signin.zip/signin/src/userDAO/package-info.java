/**
 * 
 */
/**
 * @author PRAKASH SPS
 *
 */
package UserDAO;
public class UserDAO{
	public boolean isvaild(user c){
		if(c.getUname().equls("spssps")&&c.pwd().equls("1234"))
			return true;
		else
			return false;
		
	}
}